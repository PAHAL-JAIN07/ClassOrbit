# ClassOrbit — Teacher & Student Learning Platform

ClassOrbit is a full-stack Python web application for teachers and students. It combines class management, assessment-based learning-gap indicators, smart mark-sheet import, subject-wise attendance with a 75% recovery projection, and class-scoped learning resources.

## Features

- Separate teacher/student portals with server-enforced role permissions.
- Login, registration, password hashing, logout, and class join codes.
- Responsive, animated UI with persistent dark/light theme preference.
- Teacher-created classes and subjects.
- Manual concept-based assessment and mark entry.
- Learning-gap summaries for teachers and students based on recorded marks.
- Smart import preview for CSV, XLSX, PPTX, text PDFs, and OCR-capable images/scanned PDFs. The preview is editable and requires teacher confirmation.
- Subject/date attendance sessions, per-student present/absent records, and student-specific attendance percentages and recovery estimates.
- Upload notes, assignments, instructions, and notices in original file format; students enrolled in the selected class can download them.
- Upload size limit (20 MB), file-extension allowlist, randomized stored names, and authorized download routes.
- Automated tests for login, role separation, class creation, and download authorization.

## Quick start (Windows PowerShell)

1. Install Python 3.11+ from python.org.
2. Open PowerShell in this project folder.
3. Create and activate a virtual environment:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

4. Copy `.env.example` to `.env` and set a long random `SECRET_KEY`. SQLite is the default, so no database server is required for local testing. (The app loads `.env` automatically using `python-dotenv`; you can also set variables in PowerShell.)
5. Start the app:

```powershell
$env:SECRET_KEY = "use-a-long-random-local-secret"
python run.py
```

6. Open `http://127.0.0.1:5000`.

## Demo accounts (optional)

Create demo data explicitly from the project folder:

```powershell
$env:SECRET_KEY = "use-a-long-random-local-secret"
flask --app run.py seed-demo
```

- Teacher: `teacher@demo.local` / `Teacher123!`
- Student: `student@demo.local` / `Student123!`
- Demo class join code: `BCA3DEMO`

Demo credentials are public and must never be used for a public deployment. In production, disable/remove demo credentials and use a strong secret key.

## Run tests

```powershell
python -m unittest discover -s tests -v
```

## MySQL configuration

Create a database, install the listed PyMySQL dependency, then set `DATABASE_URL`, for example:

```powershell
$env:DATABASE_URL = "mysql+pymysql://username:password@localhost/classorbit?charset=utf8mb4"
python run.py
```

URL-encode special characters in the password. Use a dedicated database user with only the required privileges.

## OCR setup

Image and scanned-PDF OCR needs the Tesseract executable installed separately on the machine, in addition to `pytesseract`. Install Tesseract for your OS and ensure `tesseract` is on PATH. Digital PDFs and CSV/XLSX files generally produce more reliable extraction. PowerPoint extraction reads slide text and tables; complex embedded images may need manual transcription or OCR enhancement.

## Smart import behavior and limitations

- Import is a **review workflow**, not automatic grading. Extracted rows are not saved until the teacher submits the confirmation form.
- Current MVP extraction expects a table-like layout with a student name and a numeric marks column. Complex multi-question mark sheets need teacher cleanup or a future column-mapping interface.
- Only names that exactly match students enrolled in the selected subject's class are saved; unmatched rows are skipped, and an import with no matching students is rejected.
- The initial MVP associates one assessment with one concept field. A future version should support question-to-concept mapping for richer analytics.
- It does not grade handwritten answers or infer a student's exact misconception from a total score.

## Attendance calculation

Attendance percentage = present records / recorded sessions for the subject × 100. For a target proportion `p`, current attended sessions `A`, and total sessions `T`, the number of consecutive future classes to attend is `max(0, ceil((p*T - A)/(1-p)))`. This assumes no future absences and equal session weights. The default target is 75%; institutions may have different policies.

## Security and deployment checklist

- Set a strong unique `SECRET_KEY`; never commit `.env` or credentials.
- Use HTTPS and a production WSGI server; do not run Flask debug mode publicly.
- Configure secure cookie settings and CSRF protection before deployment. This starter does not include Flask-WTF/CSRF tokens yet; add CSRF protection before exposing form endpoints to the public internet.
- Review file contents and malware risks before enabling ZIP/DOCX uploads in a public deployment.
- Keep student data private, obtain appropriate consent, and define retention/deletion policies.
- Use database migrations (e.g. Flask-Migrate) for schema changes rather than relying on `create_all()` in production.

## Tech stack

Python · Flask · Flask-Login · Flask-SQLAlchemy · SQLite by default / MySQL supported · Pandas · PyMuPDF · python-pptx · pytesseract · Pillow · HTML/CSS/JavaScript · Lucide icons.
