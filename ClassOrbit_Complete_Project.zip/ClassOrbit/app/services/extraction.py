"""Best-effort table/text extraction for teacher mark-sheet imports.
OCR requires the Tesseract executable installed on the host, not just pytesseract.
Extraction is only a preview; teachers must verify and confirm before records are saved.
"""
import csv, io, re

def _normalise(rows):
    clean=[]
    for row in rows:
        vals=[str(x).strip() if x is not None else '' for x in row]
        if any(vals): clean.append(vals)
    if not clean: return []
    # Find a likely header row, then return normalized name/marks pairs.
    header_idx=None
    for i,row in enumerate(clean[:5]):
        joined=' '.join(row).lower()
        if any(k in joined for k in ('name','student','roll','marks','score')):
            header_idx=i; break
    data=clean[header_idx+1:] if header_idx is not None else clean
    out=[]
    for row in data:
        # Typical tables: roll, name, marks OR name, marks. Choose a plausible name and last numeric value.
        numeric=[]
        for cell_index, cell in enumerate(row):
            try: numeric.append((cell_index,float(cell.replace('%',''))))
            except (ValueError,AttributeError): pass
        if not numeric: continue
        mark_idx,mark=numeric[-1]
        name=' '.join(cell for j,cell in enumerate(row[:mark_idx]) if cell and not re.fullmatch(r'\d+',cell)).strip()
        if not name:
            # For two-column name/marks tables, the first cell may be numeric roll; keep a non-mark first cell if present.
            name=next((c for c in row if c and not re.fullmatch(r'-?\d+(\.\d+)?',c)), '')
        if name and name.lower() not in ('name','student name','roll no','roll number','marks','score'):
            out.append({'name':name,'marks':mark})
    return out

def extract_rows(file, ext):
    data=file.read(); file.stream.seek(0)
    if ext=='csv':
        text=data.decode('utf-8-sig',errors='replace')
        return _normalise(list(csv.reader(io.StringIO(text))))
    if ext=='xlsx':
        import pandas as pd
        df=pd.read_excel(io.BytesIO(data),header=None,dtype=str).fillna('')
        return _normalise(df.values.tolist())
    if ext=='pptx':
        from pptx import Presentation
        prs=Presentation(io.BytesIO(data)); rows=[]
        for slide in prs.slides:
            for shape in slide.shapes:
                if getattr(shape,'has_table',False): rows.extend([[c.text for c in r.cells] for r in shape.table.rows])
                elif getattr(shape,'has_text_frame',False):
                    for line in shape.text.splitlines():
                        if line.strip(): rows.append(re.split(r'[,;	|]+',line))
        return _normalise(rows)
    if ext=='pdf':
        import fitz
        doc=fitz.open(stream=data,filetype='pdf'); rows=[]
        for page in doc:
            text=page.get_text('text')
            if text.strip():
                for line in text.splitlines():
                    if line.strip(): rows.append(re.split(r'\s{2,}|[,;	|]+',line.strip()))
            else:
                try:
                    import pytesseract
                    from PIL import Image
                    pix=page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
                    img=Image.open(io.BytesIO(pix.tobytes('png')))
                    for line in pytesseract.image_to_string(img).splitlines():
                        if line.strip(): rows.append(re.split(r'\s{2,}|[,;	|]+',line.strip()))
                except Exception: pass
        return _normalise(rows)
    if ext in ('png','jpg','jpeg','webp'):
        from PIL import Image
        import pytesseract
        img=Image.open(io.BytesIO(data)).convert('RGB')
        text=pytesseract.image_to_string(img)
        return _normalise([re.split(r'\s{2,}|[,;	|]+',line.strip()) for line in text.splitlines() if line.strip()])
    raise ValueError('This file type is not supported for marks extraction.')
