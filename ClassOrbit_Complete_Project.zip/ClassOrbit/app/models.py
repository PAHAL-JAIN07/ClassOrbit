from datetime import datetime, date
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # teacher / student
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)

class Classroom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    join_code = db.Column(db.String(24), unique=True, nullable=False, index=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    teacher = db.relationship('User', backref='classrooms')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    classroom_id = db.Column(db.Integer, db.ForeignKey('classroom.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    classroom = db.relationship('Classroom', backref=db.backref('enrollments', cascade='all, delete-orphan'))
    student = db.relationship('User', backref='enrollments')
    __table_args__ = (db.UniqueConstraint('classroom_id', 'student_id', name='unique_enrollment'),)

class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    classroom_id = db.Column(db.Integer, db.ForeignKey('classroom.id'), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    classroom = db.relationship('Classroom', backref=db.backref('subjects', cascade='all, delete-orphan'))

class Assessment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(160), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)
    concept = db.Column(db.String(120), nullable=False)
    max_marks = db.Column(db.Float, nullable=False, default=10)
    assessment_date = db.Column(db.Date, default=date.today, nullable=False)
    subject = db.relationship('Subject', backref=db.backref('assessments', cascade='all, delete-orphan'))

class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey('assessment.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    marks = db.Column(db.Float, nullable=False)
    assessment = db.relationship('Assessment', backref=db.backref('scores', cascade='all, delete-orphan'))
    student = db.relationship('User', backref='scores')
    __table_args__ = (db.UniqueConstraint('assessment_id', 'student_id', name='unique_score'),)

class AttendanceSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)
    session_date = db.Column(db.Date, nullable=False, default=date.today)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    subject = db.relationship('Subject', backref=db.backref('attendance_sessions', cascade='all, delete-orphan'))
    __table_args__ = (db.UniqueConstraint('subject_id', 'session_date', name='unique_attendance_day_subject'),)

class AttendanceRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('attendance_session.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    present = db.Column(db.Boolean, nullable=False, default=False)
    session = db.relationship('AttendanceSession', backref=db.backref('records', cascade='all, delete-orphan'))
    student = db.relationship('User', backref='attendance_records')
    __table_args__ = (db.UniqueConstraint('session_id', 'student_id', name='unique_attendance_record'),)

class Resource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    description = db.Column(db.Text, default='')
    category = db.Column(db.String(30), nullable=False) # note, assignment, instruction, notice
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=True)
    classroom_id = db.Column(db.Integer, db.ForeignKey('classroom.id'), nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    due_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    subject = db.relationship('Subject')
    classroom = db.relationship('Classroom')
    teacher = db.relationship('User')

class Notice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    body = db.Column(db.Text, nullable=False)
    classroom_id = db.Column(db.Integer, db.ForeignKey('classroom.id'), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    classroom = db.relationship('Classroom')
