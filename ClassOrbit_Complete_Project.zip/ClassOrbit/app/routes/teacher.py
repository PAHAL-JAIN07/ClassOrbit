from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from datetime import date, datetime
from pathlib import Path
import secrets, os, csv, io
from app import db
from app.models import User, Classroom, Enrollment, Subject, Assessment, Score, AttendanceSession, AttendanceRecord, Resource, Notice
from app.utils import role_required, teacher_owns_class
from app.services.extraction import extract_rows

teacher_bp=Blueprint('teacher',__name__)

@teacher_bp.route('/')
@login_required
@role_required('teacher')
def dashboard():
    classes=Classroom.query.filter_by(teacher_id=current_user.id).all()
    subjects=Subject.query.filter_by(teacher_id=current_user.id).all()
    resources=Resource.query.filter_by(uploaded_by=current_user.id).order_by(Resource.created_at.desc()).limit(5).all()
    student_ids={e.student_id for c in classes for e in c.enrollments}
    return render_template('teacher/dashboard.html', classes=classes, subjects=subjects, student_count=len(student_ids), resources=resources)

@teacher_bp.route('/classes',methods=['GET','POST'])
@login_required
@role_required('teacher')
def classes():
    if request.method=='POST':
        name=request.form.get('name','').strip()
        if not name:
            flash('Class name is required.','error')
        else:
            code=secrets.token_hex(4).upper()
            db.session.add(Classroom(name=name,join_code=code,teacher_id=current_user.id)); db.session.commit()
            flash(f'Class created. Share join code {code} with students.','success')
            return redirect(url_for('teacher.classes'))
    classes=Classroom.query.filter_by(teacher_id=current_user.id).all()
    return render_template('teacher/classes.html',classes=classes)

@teacher_bp.route('/classes/<int:class_id>/subjects',methods=['GET','POST'])
@login_required
@role_required('teacher')
def subjects(class_id):
    classroom=db.session.get(Classroom,class_id)
    if not teacher_owns_class(classroom): return ('Not found',404)
    if request.method=='POST':
        name=request.form.get('name','').strip()
        if name:
            db.session.add(Subject(name=name,classroom_id=classroom.id,teacher_id=current_user.id)); db.session.commit(); flash('Subject added.','success')
        else: flash('Subject name is required.','error')
        return redirect(url_for('teacher.subjects',class_id=class_id))
    return render_template('teacher/subjects.html',classroom=classroom)

@teacher_bp.route('/attendance',methods=['GET','POST'])
@login_required
@role_required('teacher')
def attendance():
    subjects=Subject.query.filter_by(teacher_id=current_user.id).all()
    selected_id=request.values.get('subject_id',type=int)
    selected=next((s for s in subjects if s.id==selected_id),None)
    chosen_date=request.values.get('session_date',date.today().isoformat())
    students=[]
    if selected:
        students=[e.student for e in selected.classroom.enrollments]
    if request.method=='POST' and selected:
        try: day=date.fromisoformat(chosen_date)
        except ValueError: day=date.today()
        session=AttendanceSession.query.filter_by(subject_id=selected.id,session_date=day).first()
        if not session:
            session=AttendanceSession(subject_id=selected.id,session_date=day,created_by=current_user.id); db.session.add(session); db.session.flush()
        for student in students:
            present=request.form.get(f'student_{student.id}')=='present'
            record=AttendanceRecord.query.filter_by(session_id=session.id,student_id=student.id).first()
            if record: record.present=present
            else: db.session.add(AttendanceRecord(session_id=session.id,student_id=student.id,present=present))
        db.session.commit(); flash('Attendance saved successfully.','success')
        return redirect(url_for('teacher.attendance',subject_id=selected.id,session_date=day.isoformat()))
    existing=None
    if selected:
        try: day=date.fromisoformat(chosen_date)
        except ValueError: day=date.today()
        existing=AttendanceSession.query.filter_by(subject_id=selected.id,session_date=day).first()
    records={r.student_id:r.present for r in existing.records} if existing else {}
    return render_template('teacher/attendance.html',subjects=subjects,selected=selected,students=students,chosen_date=chosen_date,records=records)

@teacher_bp.route('/assessments',methods=['GET','POST'])
@login_required
@role_required('teacher')
def assessments():
    subjects=Subject.query.filter_by(teacher_id=current_user.id).all()
    if request.method=='POST':
        try:
            subject=next(s for s in subjects if s.id==int(request.form.get('subject_id','0')))
            title=request.form.get('title','').strip(); concept=request.form.get('concept','').strip(); max_marks=float(request.form.get('max_marks','10'))
            if not title or not concept or max_marks<=0: raise ValueError()
            a=Assessment(title=title,subject_id=subject.id,concept=concept,max_marks=max_marks); db.session.add(a); db.session.flush()
            for e in subject.classroom.enrollments:
                raw=request.form.get(f'marks_{e.student_id}','').strip()
                if raw:
                    mark=float(raw)
                    if mark<0 or mark>max_marks: raise ValueError(f'Marks must be between 0 and {max_marks}.')
                    db.session.add(Score(assessment_id=a.id,student_id=e.student_id,marks=mark))
            db.session.commit(); flash('Assessment and marks saved.','success'); return redirect(url_for('teacher.assessments'))
        except StopIteration: flash('Select one of your subjects.','error')
        except (ValueError,TypeError) as exc: db.session.rollback(); flash(str(exc) or 'Check marks and assessment details.','error')
    return render_template('teacher/assessments.html',subjects=subjects,assessments=Assessment.query.join(Subject).filter(Subject.teacher_id==current_user.id).order_by(Assessment.assessment_date.desc()).all())

@teacher_bp.route('/learning-gaps')
@login_required
@role_required('teacher')
def learning_gaps():
    subjects=Subject.query.filter_by(teacher_id=current_user.id).all(); stats=[]
    for subject in subjects:
        for a in subject.assessments:
            scores=a.scores
            if scores:
                avg=sum(x.marks/a.max_marks*100 for x in scores)/len(scores)
                stats.append({'subject':subject.name,'concept':a.concept,'assessment':a.title,'average':round(avg,1),'count':len(scores)})
    stats.sort(key=lambda x:x['average'])
    return render_template('teacher/learning_gaps.html',stats=stats)

@teacher_bp.route('/import',methods=['GET','POST'])
@login_required
@role_required('teacher')
def smart_import():
    subjects=Subject.query.filter_by(teacher_id=current_user.id).all()
    rows=[]; filename=''; error=None
    if request.method=='POST':
        file=request.files.get('file')
        if not file or not file.filename: error='Choose a file first.'
        else:
            ext=file.filename.rsplit('.',1)[-1].lower() if '.' in file.filename else ''
            if ext not in current_app.config['ALLOWED_EXTENSIONS']: error='Unsupported file type. Use PDF, image, PPTX, XLSX, CSV, DOCX, TXT, or ZIP for resources; marks extraction supports PDF, image, PPTX, XLSX and CSV.'
            elif not subjects: error='Create a class and subject before importing marks.'
            else:
                filename=secure_filename(file.filename)
                try: rows=extract_rows(file,ext)
                except Exception as exc: error=f'Could not read this file. Try a clearer scan or CSV/XLSX. Details: {str(exc)[:180]}'
                if not rows and not error: error='No table-like rows found. For images/scanned PDFs, install Tesseract OCR and ensure the text is clear.'
                # Preserve extracted rows in the rendered form; saving is a separate confirmed POST.
                if rows:
                    return render_template('teacher/import_preview.html',rows=rows,subjects=subjects,filename=filename)
    return render_template('teacher/import.html',subjects=subjects,error=error)

@teacher_bp.route('/import/confirm',methods=['POST'])
@login_required
@role_required('teacher')
def confirm_import():
    try:
        subject=next(s for s in Subject.query.filter_by(teacher_id=current_user.id).all() if s.id==int(request.form.get('subject_id','0')))
        title=request.form.get('title','Imported assessment').strip() or 'Imported assessment'
        concept=request.form.get('concept','Imported concepts').strip() or 'Imported concepts'
        max_marks=float(request.form.get('max_marks','100'))
        if max_marks<=0: raise ValueError('Maximum marks must be positive.')
        names=request.form.getlist('student_name[]'); marks=request.form.getlist('marks[]')
        if not names or len(names)!=len(marks): raise ValueError('No valid preview rows were submitted.')
        assessment=Assessment(title=title,subject_id=subject.id,concept=concept,max_marks=max_marks); db.session.add(assessment); db.session.flush()
        enrolled={e.student.name.lower():e.student for e in subject.classroom.enrollments}
        saved=0
        seen=set()
        for name,raw in zip(names,marks):
            if not name.strip() or not raw.strip(): continue
            mark=float(raw)
            if mark<0 or mark>max_marks: raise ValueError(f'Mark {mark} must be between 0 and {max_marks}.')
            student=enrolled.get(name.strip().lower())
            if student:
                if student.id in seen:
                    raise ValueError(f'Duplicate rows were found for {student.name}. Remove the duplicate before confirming.')
                seen.add(student.id)
                db.session.add(Score(assessment_id=assessment.id,student_id=student.id,marks=mark)); saved+=1
        if saved==0: raise ValueError('No rows matched enrolled students by exact name. Correct names or enroll students first.')
        db.session.commit(); flash(f'Imported {saved} marks after your confirmation.','success')
    except StopIteration: db.session.rollback(); flash('Select one of your subjects.','error')
    except (ValueError,TypeError) as exc: db.session.rollback(); flash(str(exc) or 'Import validation failed.','error')
    return redirect(url_for('teacher.smart_import'))

@teacher_bp.route('/resources',methods=['GET','POST'])
@login_required
@role_required('teacher')
def manage_resources():
    classes=Classroom.query.filter_by(teacher_id=current_user.id).all()
    subjects=Subject.query.filter_by(teacher_id=current_user.id).all()
    if request.method=='POST':
        f=request.files.get('file'); title=request.form.get('title','').strip(); category=request.form.get('category','note'); class_id=request.form.get('classroom_id',type=int); subject_id=request.form.get('subject_id',type=int)
        classroom=next((c for c in classes if c.id==class_id),None)
        if not f or not f.filename or not title or category not in ('note','assignment','instruction','notice') or not classroom:
            flash('Complete the title, class, category, and file fields.','error')
        else:
            original=secure_filename(f.filename); ext=original.rsplit('.',1)[-1].lower() if '.' in original else ''
            if ext not in current_app.config['ALLOWED_EXTENSIONS']:
                flash('Unsupported file type.','error')
            else:
                stored=f'{secrets.token_hex(16)}_{original}'
                f.save(os.path.join(current_app.config['UPLOAD_FOLDER'],stored))
                subject=next((s for s in subjects if s.id==subject_id and s.classroom_id==classroom.id),None) if subject_id else None
                due=None
                try: due=date.fromisoformat(request.form.get('due_date','')) if request.form.get('due_date') else None
                except ValueError: due=None
                resource=Resource(title=title,description=request.form.get('description','').strip(),category=category,filename=stored,original_filename=original,subject_id=subject.id if subject else None,classroom_id=classroom.id,uploaded_by=current_user.id,due_date=due)
                db.session.add(resource)
                if category=='notice' and request.form.get('description','').strip(): db.session.add(Notice(title=title,body=request.form.get('description').strip(),classroom_id=classroom.id,teacher_id=current_user.id))
                db.session.commit(); flash('Resource published to the selected class.','success'); return redirect(url_for('teacher.manage_resources'))
    resources=Resource.query.filter_by(uploaded_by=current_user.id).order_by(Resource.created_at.desc()).all()
    return render_template('teacher/resources.html',classes=classes,subjects=subjects,resources=resources)
