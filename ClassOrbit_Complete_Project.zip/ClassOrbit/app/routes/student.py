from flask import Blueprint, render_template, request
from flask_login import login_required, current_user
from app.utils import role_required
from app.models import Enrollment, Subject, AttendanceSession, AttendanceRecord, Assessment, Score, Resource, Notice
from app import db
from sqlalchemy import func
from datetime import date
student_bp=Blueprint('student',__name__)

@student_bp.route('/')
@login_required
@role_required('student')
def dashboard():
    enrollments=Enrollment.query.filter_by(student_id=current_user.id).all()
    class_ids=[e.classroom_id for e in enrollments]
    resources=Resource.query.filter(Resource.classroom_id.in_(class_ids)).order_by(Resource.created_at.desc()).limit(6).all() if class_ids else []
    notices=Notice.query.filter(Notice.classroom_id.in_(class_ids)).order_by(Notice.created_at.desc()).limit(5).all() if class_ids else []
    gaps=[]
    for score in Score.query.filter_by(student_id=current_user.id).all():
        a=score.assessment
        pct=score.marks/a.max_marks*100 if a.max_marks else 0
        if pct<75: gaps.append({'subject':a.subject.name,'concept':a.concept,'pct':round(pct,1),'assessment':a.title})
    attendance=attendance_summary()
    return render_template('student/dashboard.html',resources=resources,notices=notices,gaps=gaps[:5],attendance=attendance)

def attendance_summary():
    data=[]
    for enrollment in Enrollment.query.filter_by(student_id=current_user.id).all():
        for subject in enrollment.classroom.subjects:
            sessions=AttendanceSession.query.filter_by(subject_id=subject.id).all()
            total=len(sessions)
            records=AttendanceRecord.query.filter(AttendanceRecord.student_id==current_user.id,AttendanceRecord.session_id.in_([s.id for s in sessions])).all() if sessions else []
            attended=sum(1 for r in records if r.present)
            pct=round(attended/total*100,1) if total else 0
            target=75
            needed=max(0,__import__('math').ceil((target/100*total-attended)/(1-target/100))) if total else 0
            data.append({'subject':subject,'total':total,'attended':attended,'pct':pct,'needed':needed,'shortage':total>0 and pct<target})
    return data

@student_bp.route('/attendance')
@login_required
@role_required('student')
def attendance():
    return render_template('student/attendance.html',attendance=attendance_summary())

@student_bp.route('/learning-gaps')
@login_required
@role_required('student')
def learning_gaps():
    gaps=[]
    for score in Score.query.filter_by(student_id=current_user.id).all():
        a=score.assessment; pct=score.marks/a.max_marks*100 if a.max_marks else 0
        gaps.append({'subject':a.subject.name,'concept':a.concept,'assessment':a.title,'pct':round(pct,1),'priority':pct<75})
    gaps.sort(key=lambda x:x['pct'])
    return render_template('student/learning_gaps.html',gaps=gaps)

@student_bp.route('/resources')
@login_required
@role_required('student')
def resources():
    ids=[e.classroom_id for e in Enrollment.query.filter_by(student_id=current_user.id).all()]
    category=request.args.get('category','')
    query=Resource.query.filter(Resource.classroom_id.in_(ids)) if ids else Resource.query.filter(False)
    if category in ('note','assignment','instruction','notice'): query=query.filter_by(category=category)
    items=query.order_by(Resource.created_at.desc()).all()
    return render_template('student/resources.html',resources=items,category=category)
