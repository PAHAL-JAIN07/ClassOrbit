from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, current_user
from app import db
from app.models import User, Enrollment, Classroom
from werkzeug.security import generate_password_hash
import re

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('teacher.dashboard' if current_user.role == 'teacher' else 'student.dashboard'))
    if request.method == 'POST':
        email = request.form.get('email','').strip().lower()
        password = request.form.get('password','')
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user, remember=bool(request.form.get('remember')))
            flash('Welcome back! You are signed in.', 'success')
            return redirect(url_for('teacher.dashboard' if user.role == 'teacher' else 'student.dashboard'))
        flash('Email or password was not recognized.', 'error')
    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET','POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        name=request.form.get('name','').strip()
        email=request.form.get('email','').strip().lower()
        password=request.form.get('password','')
        role=request.form.get('role','student')
        join_code=request.form.get('join_code','').strip().upper()
        if not name or not email or len(password)<8 or role not in ('teacher','student'):
            flash('Enter your name, valid email, role, and a password of at least 8 characters.', 'error')
        elif User.query.filter_by(email=email).first():
            flash('An account with that email already exists.', 'error')
        elif role == 'student' and not Classroom.query.filter_by(join_code=join_code).first():
            flash('Enter a valid class join code supplied by your teacher.', 'error')
        else:
            user=User(name=name,email=email,role=role)
            user.set_password(password)
            db.session.add(user); db.session.flush()
            if role == 'student':
                classroom=Classroom.query.filter_by(join_code=join_code).first()
                db.session.add(Enrollment(classroom_id=classroom.id,student_id=user.id))
            db.session.commit()
            login_user(user)
            flash('Your account is ready.', 'success')
            return redirect(url_for('teacher.dashboard' if role=='teacher' else 'student.dashboard'))
    return render_template('auth/register.html')

@auth_bp.route('/logout', methods=['POST'])
def logout():
    logout_user()
    flash('You have been signed out.', 'success')
    return redirect(url_for('auth.login'))
