from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user
main_bp=Blueprint('main',__name__)
@main_bp.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('teacher.dashboard' if current_user.role=='teacher' else 'student.dashboard'))
    return render_template('landing.html')
