from flask import Blueprint, abort, current_app, send_from_directory
from flask_login import login_required, current_user
from app.models import Resource, Enrollment, Classroom
from app.utils import role_required
from pathlib import Path
resources_bp=Blueprint('resources',__name__)
@resources_bp.route('/<int:resource_id>/download')
@login_required
def download(resource_id):
    resource=Resource.query.get_or_404(resource_id)
    if current_user.role=='teacher':
        if resource.uploaded_by != current_user.id: abort(403)
    elif current_user.role=='student':
        enrolled={e.classroom_id for e in Enrollment.query.filter_by(student_id=current_user.id).all()}
        if resource.classroom_id not in enrolled: abort(403)
    else: abort(403)
    return send_from_directory(current_app.config['UPLOAD_FOLDER'],resource.filename,as_attachment=True,download_name=resource.original_filename)
