from functools import wraps
from flask import abort
from flask_login import current_user

def role_required(role):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if current_user.role != role:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return decorator

def teacher_owns_class(classroom):
    return classroom is not None and classroom.teacher_id == current_user.id
