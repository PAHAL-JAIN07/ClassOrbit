from flask import Flask, redirect, url_for
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from config import Config
from pathlib import Path

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message_category = "info"

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    db.init_app(app)
    login_manager.init_app(app)

    from app.models import User, Classroom, Enrollment, Subject, Assessment, Score, AttendanceSession, AttendanceRecord, Resource, Notice
    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.teacher import teacher_bp
    from app.routes.student import student_bp
    from app.routes.resources import resources_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(teacher_bp, url_prefix="/teacher")
    app.register_blueprint(student_bp, url_prefix="/student")
    app.register_blueprint(resources_bp, url_prefix="/resources")

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    with app.app_context():
        db.create_all()
        # Optional demo data is intentionally opt-in: set SEED_DEMO=1 and run `flask --app run.py seed-demo` only in a local demo.
        @app.cli.command("seed-demo")
        def seed_demo():
            """Create a small demo teacher, student, class and subjects if the database is empty."""
            from werkzeug.security import generate_password_hash
            if User.query.filter_by(email="teacher@demo.local").first():
                print("Demo data already exists.")
                return
            t = User(name="Demo Teacher", email="teacher@demo.local", password_hash=generate_password_hash("Teacher123!"), role="teacher")
            s = User(name="Demo Student", email="student@demo.local", password_hash=generate_password_hash("Student123!"), role="student")
            db.session.add_all([t, s]); db.session.flush()
            c = Classroom(name="BCA Semester 3", join_code="BCA3DEMO", teacher_id=t.id)
            db.session.add(c); db.session.flush()
            db.session.add(Enrollment(classroom_id=c.id, student_id=s.id))
            for name in ["Python", "Advanced Java", "Mathematics"]:
                db.session.add(Subject(name=name, classroom_id=c.id, teacher_id=t.id))
            db.session.commit()
            print("Demo accounts created: teacher@demo.local / Teacher123! and student@demo.local / Student123!")
    return app
