document.addEventListener('DOMContentLoaded',()=>{
  const root=document.documentElement, toggle=document.getElementById('themeToggle');
  const saved=localStorage.getItem('classorbit-theme');
  if(saved==='dark'||saved==='light') root.dataset.theme=saved;
  function icon(){ if(toggle){toggle.innerHTML=root.dataset.theme==='dark'?'<i data-lucide="sun"></i>':'<i data-lucide="moon"></i>'; if(window.lucide) window.lucide.createIcons();}}
  icon(); if(toggle) toggle.addEventListener('click',()=>{root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';localStorage.setItem('classorbit-theme',root.dataset.theme);icon();});
  if(window.lucide) window.lucide.createIcons();
  document.querySelectorAll('.flash-close').forEach(b=>b.addEventListener('click',()=>b.closest('.flash').remove()));
  const role=document.getElementById('roleSelect'),join=document.getElementById('joinCodeWrap');
  function roleChange(){if(role&&join){join.hidden=role.value!=='student'; const input=join.querySelector('input'); if(input) input.required=role.value==='student';}}
  if(role){role.addEventListener('change',roleChange);roleChange();}
  const fi=document.getElementById('fileInput'), sf=document.getElementById('selectedFile');
  if(fi&&sf)fi.addEventListener('change',()=>{sf.textContent=fi.files.length?`Selected: ${fi.files[0].name} · ${(fi.files[0].size/1024/1024).toFixed(2)} MB`:'';});
  const classSel=document.getElementById('resourceClass'),subSel=document.getElementById('resourceSubject');
  function filterSubjects(){if(!classSel||!subSel)return;const cid=classSel.value;[...subSel.options].forEach(o=>{if(!o.value)return;o.hidden=!!cid&&o.dataset.class!==cid;if(o.hidden&&o.selected)subSel.value='';});}
  if(classSel){classSel.addEventListener('change',filterSubjects);filterSubjects();}
  const as=document.getElementById('assessmentSubject'), list=document.getElementById('assessmentStudents');
  function studentFields(){if(!as||!list)return;const id=as.value;const people=(window.CLASSORBIT_CLASS_STUDENTS||{})[id]||[];if(!id){list.innerHTML='<p class="muted">Select a subject above to show student mark fields.</p>';return;}if(!people.length){list.innerHTML='<p class="muted">No students are enrolled in this subject’s class yet.</p>';return;}list.innerHTML=people.map(s=>`<label class="mark-entry"><span>${escapeHtml(s.name)}</span><input name="marks_${s.id}" type="number" min="0" step="0.1" placeholder="Marks (optional)"></label>`).join('');}
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  if(as){as.addEventListener('change',studentFields);studentFields();}
  // Respect reduced-motion preferences; CSS handles the actual animation rules.
});
