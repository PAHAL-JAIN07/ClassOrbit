import tempfile, os, unittest
from app import create_app, db
from app.models import User, Classroom, Enrollment, Subject, Resource

class ClassOrbitTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.app=create_app({'TESTING':True,'SECRET_KEY':'test-secret','SQLALCHEMY_DATABASE_URI':'sqlite:///'+os.path.join(self.tmp.name,'test.db'),'UPLOAD_FOLDER':os.path.join(self.tmp.name,'uploads'),'WTF_CSRF_ENABLED':False})
        self.client=self.app.test_client()
        with self.app.app_context():
            db.drop_all(); db.create_all()
            t=User(name='Teacher One',email='teacher@test.local',role='teacher'); t.set_password('Password123')
            s=User(name='Student One',email='student@test.local',role='student'); s.set_password('Password123')
            db.session.add_all([t,s]); db.session.flush()
            c=Classroom(name='BCA',join_code='TESTCODE',teacher_id=t.id); db.session.add(c); db.session.flush()
            db.session.add(Enrollment(classroom_id=c.id,student_id=s.id)); db.session.add(Subject(name='Python',classroom_id=c.id,teacher_id=t.id)); db.session.commit()
    def tearDown(self):
        with self.app.app_context(): db.session.remove(); db.drop_all()
        self.tmp.cleanup()
    def test_landing_and_login(self):
        self.assertEqual(self.client.get('/').status_code,200)
        r=self.client.post('/login',data={'email':'teacher@test.local','password':'Password123'},follow_redirects=True)
        self.assertEqual(r.status_code,200); self.assertIn(b'YOUR TEACHING SPACE',r.data)
    def test_student_role_and_teacher_route_blocked(self):
        r=self.client.post('/register',data={'name':'New Student','email':'new@test.local','password':'Password123','role':'student','join_code':'TESTCODE'},follow_redirects=True)
        self.assertEqual(r.status_code,200); self.assertIn(b'YOUR LEARNING SPACE',r.data)
        blocked=self.client.get('/teacher/')
        self.assertEqual(blocked.status_code,403)
    def test_teacher_can_create_class(self):
        self.client.post('/login',data={'email':'teacher@test.local','password':'Password123'})
        r=self.client.post('/teacher/classes',data={'name':'New class'},follow_redirects=True)
        self.assertEqual(r.status_code,200); self.assertIn(b'New class',r.data)
    def test_student_cannot_download_unenrolled_resource(self):
        with self.app.app_context():
            teacher=User.query.filter_by(email='teacher@test.local').first(); c=Classroom.query.first()
            from pathlib import Path
            Path(self.app.config['UPLOAD_FOLDER']).mkdir(parents=True,exist_ok=True)
            Path(self.app.config['UPLOAD_FOLDER'],'private.pdf').write_bytes(b'test')
            r=Resource(title='Private',category='note',filename='private.pdf',original_filename='private.pdf',classroom_id=c.id,uploaded_by=teacher.id)
            db.session.add(r); db.session.commit(); rid=r.id
            student=User(name='Other',email='other@test.local',role='student'); student.set_password('Password123'); db.session.add(student); db.session.commit()
        self.client.post('/login',data={'email':'other@test.local','password':'Password123'})
        self.assertEqual(self.client.get(f'/resources/{rid}/download').status_code,403)

if __name__=='__main__': unittest.main()
